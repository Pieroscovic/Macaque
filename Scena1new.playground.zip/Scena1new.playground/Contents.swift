import UIKit
import SwiftUI
import PlaygroundSupport
import AVKit
struct ContentView: View {
    @State var occhisx1 = false
    @State var occhidx2 = false
    @State var occhilato = false
    @State var hippo = false
    @State var audioPlayer: AVAudioPlayer!
    @State var black = false
    @State var textElement = 0
    @State var blockTap = false
    @State var audioPlayer1: AVAudioPlayer!
    @State var audioPlayer2: AVAudioPlayer!
    @State var audioPlayer3: AVAudioPlayer!
    let hello = "The MAC-aque!"
    let dialog = ["A long time ago, in a remote land, a cutting-edge macaque lived with all his friends who admired him.", "The macaque of this story was very very loved and appreciated by those who knew him."]
    
    var body: some View {
        
        ZStack{
            
            //sfondo
            Image(uiImage: UIImage(named: "sfondo")!)
                .resizable()
                .aspectRatio(contentMode: .fit )
                .frame(width: 600)
            
            //sottofondo musicale :
                .onAppear{
                    DispatchQueue.main.asyncAfter(deadline: .now()){
                        let sound = Bundle.main.path(forResource: "sottofondo", ofType: "m4a")
                        self.audioPlayer3 = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
                        self.audioPlayer3.play()
                        self.audioPlayer3.volume = 0.5
                        self.audioPlayer3.numberOfLoops = -1
                    }}
            
            //audio1
                .onAppear{
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5){
                        let sound = Bundle.main.path(forResource: "audio1", ofType: "m4a")
                        self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
                        self.audioPlayer.play()
                        audioPlayer.volume = 1.1
                    }}
            
            //giraffe
            Image(uiImage: UIImage(named: "giraffe")!)
                .resizable()
                .aspectRatio(contentMode: .fit )
                .frame(width: 390)
                .position(x:290, y:150)
            
            //hippo
            Image(uiImage: UIImage(named: "hippo")!)
                .resizable()
                .aspectRatio(contentMode: .fit )
                .frame(width: 310)
                .offset(x : hippo ? -80 : 600)
                .offset(y : hippo ? -50 : -50 )
            
            // suono & animazione hippo
                .onAppear{
                    DispatchQueue.main.asyncAfter(deadline: .now()){
                        let sound = Bundle.main.path(forResource: "hippo1", ofType: "m4a")
                        self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
                        self.audioPlayer.play()
                        audioPlayer.volume = 0.1
                    }
                    
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1){
                        withAnimation(.linear(duration: 4)){
                            hippo.toggle()}}}
            
            //scimmia
            
            Image(uiImage: UIImage(named: "scimmiasenzasfondo")!)
                .resizable()
                .aspectRatio(contentMode: .fit )
                .frame(width: 450)
                .position(x:290, y:270)
            
            //macache
            Image(uiImage: UIImage(named: "macachesenzasfondo")!)
                .resizable()
                .aspectRatio(contentMode: .fit )
                .frame(width: 500)
                .position(x:350, y:250)
            
            Group{
                //occhi 1
                Image(uiImage: UIImage(named: "occhisx1")!)
                    .resizable()
                    .aspectRatio(contentMode: .fit )
                    .frame(width: 450)
                    .position(x:348, y:252)
                    .opacity(occhisx1 ? 1 : 0)
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline:.now() + 1.5){
                            withAnimation(.linear(duration:0.5).repeatForever()) {occhisx1.toggle()}
                        }
                    }
                
                // aggiungi animazione occhi macaca
                
                
                
                //occhi 2
                Image(uiImage: UIImage(named: "occhidx2")!)
                    .resizable()
                    .aspectRatio(contentMode: .fit )
                    .frame(width: 450)
                    .position(x:335, y:240)
                // aggiungi animazione occhi macaca
                    .opacity(occhidx2 ? 1 : 0)
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline:.now() + 2){
                            withAnimation(.linear(duration:0.5).repeatForever())
                            {occhidx2.toggle()}
                        }
                    }
                
            }
            
            Group{
                
                //macacalato
                Image(uiImage: UIImage(named: "macacalato")!)
                    .resizable()
                    .aspectRatio(contentMode: .fit )
                    .frame(width: 250)
                    .position(x:190, y:320)
                
                //occhi macaca
                Image(uiImage: UIImage(named: "occhilato")!)
                    .resizable()
                    .aspectRatio(contentMode: .fit )
                    .frame(width: 450)
                    .position(x:280, y:365)
                // aggiungi animazione occhi macaca
                    .opacity(occhilato ? 1 : 0)
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline:.now() + 1){
                            withAnimation(.linear(duration:0.5)
                                            .repeatForever()) {occhilato.toggle()}
                        }
                    }
                
                //  pc macaco
                Image(uiImage: UIImage(named: "pcban")!)
                    .resizable()
                    .aspectRatio(contentMode: .fit )
                    .frame(width: 225)
                    .position(x:315, y:380 )
            }
            
            
            //dialogue
            Group{
                Image(uiImage: UIImage(named: "Dialogue")!)
                    .resizable()
                    .scaledToFit()
                    .aspectRatio(contentMode: .fit )
                    .frame(width: 580)
                    .position(x:300, y:480)
                
                
                
                Text(dialog[textElement])
                    .bold()
                    .position(x: 260, y:480)
                    .frame(width: 530)
                    .multilineTextAlignment(.center)
                    .foregroundColor(Color(red : 83/255, green : 55/255, blue: 25/255))
                
                    .onAppear{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 6)
                        {blockTap.toggle()
                            black.toggle()
                        }            }
                
            }
            //
            //            Group{
            //                Image(uiImage: UIImage(named: "black")!)
            //                    .resizable()
            //                //                .aspectRatio(contentMode: .fit )
            //                //                .frame(width: 600, height: 560)
            //                    .opacity(black ? 0 : 1)
            //                    .animation(.linear(duration : 3), value : black)
            //                    .onAppear{
            //                        DispatchQueue.main.asyncAfter(deadline: .now() ){
            //                            withAnimation(.linear(duration: 10)){
            //                                black.toggle()}}}}
            //                                            Text(hello)
            ////                                                .position(x: 210, y:430)
            //                                                .frame(width: 400)
            //
            //                                                .onAppear{
            //                                                    DispatchQueue.main.asyncAfter(deadline: .now() + 6)
            //                                                                }
            //                            }
            
            
        }
        
        
        .onTapGesture {
            
            
            if textElement<dialog.count - 1
            {
                textElement = textElement + 1
                if textElement == 1
                {blockTap.toggle()
                }
            }
            //audio1
            //                                    .onAppear{
            //                                        DispatchQueue.main.asyncAfter(deadline: .now() + 6){
            let sound = Bundle.main.path(forResource: "audio2", ofType: "m4a")
            self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
            self.audioPlayer.play()
            audioPlayer.volume = 1.1
            
            
        }
        .allowsHitTesting(blockTap)
        
        
    }
    
}

struct ContentView1: View {
    @State var black = false
    @State var audioPlayer3 : AVAudioPlayer!
    var body: some View{
        
        ZStack{
            Image(uiImage: UIImage(named: "abc2.jpg")!)
                .resizable()
                .aspectRatio(contentMode: .fill )
                .frame(width: 600, height: 600)
                .opacity(black ? 0 : 1)
//                .animation(.linear(duration : 3), value : black)
//                .onAppear{
//                    DispatchQueue.main.asyncAfter(deadline: .now() ){
//                        withAnimation(.linear(duration: 10)){
//                             black.toggle()}}}
                .onAppear{
                    DispatchQueue.main.asyncAfter(deadline: .now()){
                        let sound = Bundle.main.path(forResource: "sottofondo", ofType: "m4a")
                        self.audioPlayer3 = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
                        self.audioPlayer3.play()
                        self.audioPlayer3.volume = 0.5
                        self.audioPlayer3.numberOfLoops = -1
                    }}
            
            Image(uiImage: UIImage(named : "play")!)
                .resizable()
                .scaledToFit()
                .frame(width:250)
                .onTapGesture(){
                    
                    PlaygroundPage.current.setLiveView(ContentView())
                }
            
                Text("PLAY!")
                .bold()
                .foregroundColor(Color(red : 83/255, green : 55/255, blue: 25/255))
                .font(.system(size: 50))
                .onTapGesture(){
                    
                    PlaygroundPage.current.setLiveView(ContentView())
                }
            
            
            
        }
    }
}



PlaygroundPage.current.setLiveView(ContentView1())

